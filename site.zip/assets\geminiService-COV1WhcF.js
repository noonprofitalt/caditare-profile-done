const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/reportingService-DKNwFCwn.js","assets/index-BBTYFYMN.js","assets/index-MQO13qb3.css"])))=>i.map(i=>d[i]);
import{a4 as ne}from"./index-BBTYFYMN.js";var T;(function(e){e.STRING="string",e.NUMBER="number",e.INTEGER="integer",e.BOOLEAN="boolean",e.ARRAY="array",e.OBJECT="object"})(T||(T={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var b;(function(e){e.LANGUAGE_UNSPECIFIED="language_unspecified",e.PYTHON="python"})(b||(b={}));var M;(function(e){e.OUTCOME_UNSPECIFIED="outcome_unspecified",e.OUTCOME_OK="outcome_ok",e.OUTCOME_FAILED="outcome_failed",e.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"})(M||(M={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $=["user","model","function","system"];var L;(function(e){e.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",e.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",e.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",e.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",e.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",e.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"})(L||(L={}));var x;(function(e){e.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",e.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",e.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",e.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",e.BLOCK_NONE="BLOCK_NONE"})(x||(x={}));var G;(function(e){e.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",e.NEGLIGIBLE="NEGLIGIBLE",e.LOW="LOW",e.MEDIUM="MEDIUM",e.HIGH="HIGH"})(G||(G={}));var D;(function(e){e.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",e.SAFETY="SAFETY",e.OTHER="OTHER"})(D||(D={}));var v;(function(e){e.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",e.STOP="STOP",e.MAX_TOKENS="MAX_TOKENS",e.SAFETY="SAFETY",e.RECITATION="RECITATION",e.LANGUAGE="LANGUAGE",e.BLOCKLIST="BLOCKLIST",e.PROHIBITED_CONTENT="PROHIBITED_CONTENT",e.SPII="SPII",e.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",e.OTHER="OTHER"})(v||(v={}));var P;(function(e){e.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",e.RETRIEVAL_QUERY="RETRIEVAL_QUERY",e.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",e.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",e.CLASSIFICATION="CLASSIFICATION",e.CLUSTERING="CLUSTERING"})(P||(P={}));var k;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.AUTO="AUTO",e.ANY="ANY",e.NONE="NONE"})(k||(k={}));var H;(function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.MODE_DYNAMIC="MODE_DYNAMIC"})(H||(H={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class f extends Error{constructor(t){super(`[GoogleGenerativeAI Error]: ${t}`)}}class _ extends f{constructor(t,n){super(t),this.response=n}}class z extends f{constructor(t,n,s,o){super(t),this.status=n,this.statusText=s,this.errorDetails=o}}class C extends f{}class Z extends f{}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const se="https://generativelanguage.googleapis.com",oe="v1beta",ie="0.24.1",ae="genai-js";var m;(function(e){e.GENERATE_CONTENT="generateContent",e.STREAM_GENERATE_CONTENT="streamGenerateContent",e.COUNT_TOKENS="countTokens",e.EMBED_CONTENT="embedContent",e.BATCH_EMBED_CONTENTS="batchEmbedContents"})(m||(m={}));class re{constructor(t,n,s,o,i){this.model=t,this.task=n,this.apiKey=s,this.stream=o,this.requestOptions=i}toString(){var t,n;const s=((t=this.requestOptions)===null||t===void 0?void 0:t.apiVersion)||oe;let i=`${((n=this.requestOptions)===null||n===void 0?void 0:n.baseUrl)||se}/${s}/${this.model}:${this.task}`;return this.stream&&(i+="?alt=sse"),i}}function ce(e){const t=[];return e!=null&&e.apiClient&&t.push(e.apiClient),t.push(`${ae}/${ie}`),t.join(" ")}async function le(e){var t;const n=new Headers;n.append("Content-Type","application/json"),n.append("x-goog-api-client",ce(e.requestOptions)),n.append("x-goog-api-key",e.apiKey);let s=(t=e.requestOptions)===null||t===void 0?void 0:t.customHeaders;if(s){if(!(s instanceof Headers))try{s=new Headers(s)}catch(o){throw new C(`unable to convert customHeaders value ${JSON.stringify(s)} to Headers: ${o.message}`)}for(const[o,i]of s.entries()){if(o==="x-goog-api-key")throw new C(`Cannot set reserved header name ${o}`);if(o==="x-goog-api-client")throw new C(`Header name ${o} can only be set using the apiClient field`);n.append(o,i)}}return n}async function de(e,t,n,s,o,i){const a=new re(e,t,n,s,i);return{url:a.toString(),fetchOptions:Object.assign(Object.assign({},ge(i)),{method:"POST",headers:await le(a),body:o})}}async function A(e,t,n,s,o,i={},a=fetch){const{url:r,fetchOptions:c}=await de(e,t,n,s,o,i);return ue(r,c,a)}async function ue(e,t,n=fetch){let s;try{s=await n(e,t)}catch(o){fe(o,e)}return s.ok||await he(s,e),s}function fe(e,t){let n=e;throw n.name==="AbortError"?(n=new Z(`Request aborted when fetching ${t.toString()}: ${e.message}`),n.stack=e.stack):e instanceof z||e instanceof C||(n=new f(`Error fetching from ${t.toString()}: ${e.message}`),n.stack=e.stack),n}async function he(e,t){let n="",s;try{const o=await e.json();n=o.error.message,o.error.details&&(n+=` ${JSON.stringify(o.error.details)}`,s=o.error.details)}catch{}throw new z(`Error fetching from ${t.toString()}: [${e.status} ${e.statusText}] ${n}`,e.status,e.statusText,s)}function ge(e){const t={};if((e==null?void 0:e.signal)!==void 0||(e==null?void 0:e.timeout)>=0){const n=new AbortController;(e==null?void 0:e.timeout)>=0&&setTimeout(()=>n.abort(),e.timeout),e!=null&&e.signal&&e.signal.addEventListener("abort",()=>{n.abort()}),t.signal=n.signal}return t}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function w(e){return e.text=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),O(e.candidates[0]))throw new _(`${E(e)}`,e);return Ee(e)}else if(e.promptFeedback)throw new _(`Text not available. ${E(e)}`,e);return""},e.functionCall=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),O(e.candidates[0]))throw new _(`${E(e)}`,e);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),U(e)[0]}else if(e.promptFeedback)throw new _(`Function call not available. ${E(e)}`,e)},e.functionCalls=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),O(e.candidates[0]))throw new _(`${E(e)}`,e);return U(e)}else if(e.promptFeedback)throw new _(`Function call not available. ${E(e)}`,e)},e}function Ee(e){var t,n,s,o;const i=[];if(!((n=(t=e.candidates)===null||t===void 0?void 0:t[0].content)===null||n===void 0)&&n.parts)for(const a of(o=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)a.text&&i.push(a.text),a.executableCode&&i.push("\n```"+a.executableCode.language+`
`+a.executableCode.code+"\n```\n"),a.codeExecutionResult&&i.push("\n```\n"+a.codeExecutionResult.output+"\n```\n");return i.length>0?i.join(""):""}function U(e){var t,n,s,o;const i=[];if(!((n=(t=e.candidates)===null||t===void 0?void 0:t[0].content)===null||n===void 0)&&n.parts)for(const a of(o=(s=e.candidates)===null||s===void 0?void 0:s[0].content)===null||o===void 0?void 0:o.parts)a.functionCall&&i.push(a.functionCall);if(i.length>0)return i}const Ce=[v.RECITATION,v.SAFETY,v.LANGUAGE];function O(e){return!!e.finishReason&&Ce.includes(e.finishReason)}function E(e){var t,n,s;let o="";if((!e.candidates||e.candidates.length===0)&&e.promptFeedback)o+="Response was blocked",!((t=e.promptFeedback)===null||t===void 0)&&t.blockReason&&(o+=` due to ${e.promptFeedback.blockReason}`),!((n=e.promptFeedback)===null||n===void 0)&&n.blockReasonMessage&&(o+=`: ${e.promptFeedback.blockReasonMessage}`);else if(!((s=e.candidates)===null||s===void 0)&&s[0]){const i=e.candidates[0];O(i)&&(o+=`Candidate was blocked due to ${i.finishReason}`,i.finishMessage&&(o+=`: ${i.finishMessage}`))}return o}function I(e){return this instanceof I?(this.v=e,this):new I(e)}function pe(e,t,n){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var s=n.apply(e,t||[]),o,i=[];return o={},a("next"),a("throw"),a("return"),o[Symbol.asyncIterator]=function(){return this},o;function a(d){s[d]&&(o[d]=function(l){return new Promise(function(g,y){i.push([d,l,g,y])>1||r(d,l)})})}function r(d,l){try{c(s[d](l))}catch(g){p(i[0][3],g)}}function c(d){d.value instanceof I?Promise.resolve(d.value.v).then(u,h):p(i[0][2],d)}function u(d){r("next",d)}function h(d){r("throw",d)}function p(d,l){d(l),i.shift(),i.length&&r(i[0][0],i[0][1])}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;function me(e){const t=e.body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0})),n=Se(t),[s,o]=n.tee();return{stream:_e(s),response:ye(o)}}async function ye(e){const t=[],n=e.getReader();for(;;){const{done:s,value:o}=await n.read();if(s)return w(ve(t));t.push(o)}}function _e(e){return pe(this,arguments,function*(){const n=e.getReader();for(;;){const{value:s,done:o}=yield I(n.read());if(o)break;yield yield I(w(s))}})}function Se(e){const t=e.getReader();return new ReadableStream({start(s){let o="";return i();function i(){return t.read().then(({value:a,done:r})=>{if(r){if(o.trim()){s.error(new f("Failed to parse stream"));return}s.close();return}o+=a;let c=o.match(Y),u;for(;c;){try{u=JSON.parse(c[1])}catch{s.error(new f(`Error parsing JSON response: "${c[1]}"`));return}s.enqueue(u),o=o.substring(c[0].length),c=o.match(Y)}return i()}).catch(a=>{let r=a;throw r.stack=a.stack,r.name==="AbortError"?r=new Z("Request aborted when reading from the stream"):r=new f("Error reading from the stream"),r})}}})}function ve(e){const t=e[e.length-1],n={promptFeedback:t==null?void 0:t.promptFeedback};for(const s of e){if(s.candidates){let o=0;for(const i of s.candidates)if(n.candidates||(n.candidates=[]),n.candidates[o]||(n.candidates[o]={index:o}),n.candidates[o].citationMetadata=i.citationMetadata,n.candidates[o].groundingMetadata=i.groundingMetadata,n.candidates[o].finishReason=i.finishReason,n.candidates[o].finishMessage=i.finishMessage,n.candidates[o].safetyRatings=i.safetyRatings,i.content&&i.content.parts){n.candidates[o].content||(n.candidates[o].content={role:i.content.role||"user",parts:[]});const a={};for(const r of i.content.parts)r.text&&(a.text=r.text),r.functionCall&&(a.functionCall=r.functionCall),r.executableCode&&(a.executableCode=r.executableCode),r.codeExecutionResult&&(a.codeExecutionResult=r.codeExecutionResult),Object.keys(a).length===0&&(a.text=""),n.candidates[o].content.parts.push(a)}o++}s.usageMetadata&&(n.usageMetadata=s.usageMetadata)}return n}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Q(e,t,n,s){const o=await A(t,m.STREAM_GENERATE_CONTENT,e,!0,JSON.stringify(n),s);return me(o)}async function ee(e,t,n,s){const i=await(await A(t,m.GENERATE_CONTENT,e,!1,JSON.stringify(n),s)).json();return{response:w(i)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function te(e){if(e!=null){if(typeof e=="string")return{role:"system",parts:[{text:e}]};if(e.text)return{role:"system",parts:[e]};if(e.parts)return e.role?e:{role:"system",parts:e.parts}}}function R(e){let t=[];if(typeof e=="string")t=[{text:e}];else for(const n of e)typeof n=="string"?t.push({text:n}):t.push(n);return Ie(t)}function Ie(e){const t={role:"user",parts:[]},n={role:"function",parts:[]};let s=!1,o=!1;for(const i of e)"functionResponse"in i?(n.parts.push(i),o=!0):(t.parts.push(i),s=!0);if(s&&o)throw new f("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!s&&!o)throw new f("No content is provided for sending chat message.");return s?t:n}function Re(e,t){var n;let s={model:t==null?void 0:t.model,generationConfig:t==null?void 0:t.generationConfig,safetySettings:t==null?void 0:t.safetySettings,tools:t==null?void 0:t.tools,toolConfig:t==null?void 0:t.toolConfig,systemInstruction:t==null?void 0:t.systemInstruction,cachedContent:(n=t==null?void 0:t.cachedContent)===null||n===void 0?void 0:n.name,contents:[]};const o=e.generateContentRequest!=null;if(e.contents){if(o)throw new C("CountTokensRequest must have one of contents or generateContentRequest, not both.");s.contents=e.contents}else if(o)s=Object.assign(Object.assign({},s),e.generateContentRequest);else{const i=R(e);s.contents=[i]}return{generateContentRequest:s}}function F(e){let t;return e.contents?t=e:t={contents:[R(e)]},e.systemInstruction&&(t.systemInstruction=te(e.systemInstruction)),t}function Ae(e){return typeof e=="string"||Array.isArray(e)?{content:R(e)}:e}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],Oe={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function we(e){let t=!1;for(const n of e){const{role:s,parts:o}=n;if(!t&&s!=="user")throw new f(`First content should be with role 'user', got ${s}`);if(!$.includes(s))throw new f(`Each item should include role field. Got ${s} but valid roles are: ${JSON.stringify($)}`);if(!Array.isArray(o))throw new f("Content should have 'parts' property with an array of Parts");if(o.length===0)throw new f("Each Content should have at least one part");const i={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(const r of o)for(const c of K)c in r&&(i[c]+=1);const a=Oe[s];for(const r of K)if(!a.includes(r)&&i[r]>0)throw new f(`Content with role '${s}' can't contain '${r}' part`);t=!0}}function j(e){var t;if(e.candidates===void 0||e.candidates.length===0)return!1;const n=(t=e.candidates[0])===null||t===void 0?void 0:t.content;if(n===void 0||n.parts===void 0||n.parts.length===0)return!1;for(const s of n.parts)if(s===void 0||Object.keys(s).length===0||s.text!==void 0&&s.text==="")return!1;return!0}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const B="SILENT_ERROR";class Ne{constructor(t,n,s,o={}){this.model=n,this.params=s,this._requestOptions=o,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=t,s!=null&&s.history&&(we(s.history),this._history=s.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(t,n={}){var s,o,i,a,r,c;await this._sendPromise;const u=R(t),h={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(a=this.params)===null||a===void 0?void 0:a.toolConfig,systemInstruction:(r=this.params)===null||r===void 0?void 0:r.systemInstruction,cachedContent:(c=this.params)===null||c===void 0?void 0:c.cachedContent,contents:[...this._history,u]},p=Object.assign(Object.assign({},this._requestOptions),n);let d;return this._sendPromise=this._sendPromise.then(()=>ee(this._apiKey,this.model,h,p)).then(l=>{var g;if(j(l.response)){this._history.push(u);const y=Object.assign({parts:[],role:"model"},(g=l.response.candidates)===null||g===void 0?void 0:g[0].content);this._history.push(y)}else{const y=E(l.response);y&&console.warn(`sendMessage() was unsuccessful. ${y}. Inspect response object for details.`)}d=l}).catch(l=>{throw this._sendPromise=Promise.resolve(),l}),await this._sendPromise,d}async sendMessageStream(t,n={}){var s,o,i,a,r,c;await this._sendPromise;const u=R(t),h={safetySettings:(s=this.params)===null||s===void 0?void 0:s.safetySettings,generationConfig:(o=this.params)===null||o===void 0?void 0:o.generationConfig,tools:(i=this.params)===null||i===void 0?void 0:i.tools,toolConfig:(a=this.params)===null||a===void 0?void 0:a.toolConfig,systemInstruction:(r=this.params)===null||r===void 0?void 0:r.systemInstruction,cachedContent:(c=this.params)===null||c===void 0?void 0:c.cachedContent,contents:[...this._history,u]},p=Object.assign(Object.assign({},this._requestOptions),n),d=Q(this._apiKey,this.model,h,p);return this._sendPromise=this._sendPromise.then(()=>d).catch(l=>{throw new Error(B)}).then(l=>l.response).then(l=>{if(j(l)){this._history.push(u);const g=Object.assign({},l.candidates[0].content);g.role||(g.role="model"),this._history.push(g)}else{const g=E(l);g&&console.warn(`sendMessageStream() was unsuccessful. ${g}. Inspect response object for details.`)}}).catch(l=>{l.message!==B&&console.error(l)}),d}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Te(e,t,n,s){return(await A(t,m.COUNT_TOKENS,e,!1,JSON.stringify(n),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function be(e,t,n,s){return(await A(t,m.EMBED_CONTENT,e,!1,JSON.stringify(n),s)).json()}async function Me(e,t,n,s){const o=n.requests.map(a=>Object.assign(Object.assign({},a),{model:t}));return(await A(t,m.BATCH_EMBED_CONTENTS,e,!1,JSON.stringify({requests:o}),s)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{constructor(t,n,s={}){this.apiKey=t,this._requestOptions=s,n.model.includes("/")?this.model=n.model:this.model=`models/${n.model}`,this.generationConfig=n.generationConfig||{},this.safetySettings=n.safetySettings||[],this.tools=n.tools,this.toolConfig=n.toolConfig,this.systemInstruction=te(n.systemInstruction),this.cachedContent=n.cachedContent}async generateContent(t,n={}){var s;const o=F(t),i=Object.assign(Object.assign({},this._requestOptions),n);return ee(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}async generateContentStream(t,n={}){var s;const o=F(t),i=Object.assign(Object.assign({},this._requestOptions),n);return Q(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(s=this.cachedContent)===null||s===void 0?void 0:s.name},o),i)}startChat(t){var n;return new Ne(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:(n=this.cachedContent)===null||n===void 0?void 0:n.name},t),this._requestOptions)}async countTokens(t,n={}){const s=Re(t,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),o=Object.assign(Object.assign({},this._requestOptions),n);return Te(this.apiKey,this.model,s,o)}async embedContent(t,n={}){const s=Ae(t),o=Object.assign(Object.assign({},this._requestOptions),n);return be(this.apiKey,this.model,s,o)}async batchEmbedContents(t,n={}){const s=Object.assign(Object.assign({},this._requestOptions),n);return Me(this.apiKey,this.model,t,s)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J{constructor(t){this.apiKey=t}getGenerativeModel(t,n){if(!t.model)throw new f("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new q(this.apiKey,t,n)}getGenerativeModelFromCachedContent(t,n,s){if(!t.name)throw new C("Cached content must contain a `name` field.");if(!t.model)throw new C("Cached content must contain a `model` field.");const o=["model","systemInstruction"];for(const a of o)if(n!=null&&n[a]&&t[a]&&(n==null?void 0:n[a])!==t[a]){if(a==="model"){const r=n.model.startsWith("models/")?n.model.replace("models/",""):n.model,c=t.model.startsWith("models/")?t.model.replace("models/",""):t.model;if(r===c)continue}throw new C(`Different value for "${a}" specified in modelParams (${n[a]}) and cachedContent (${t[a]})`)}const i=Object.assign(Object.assign({},n),{model:t.model,tools:t.tools,toolConfig:t.toolConfig,systemInstruction:t.systemInstruction,cachedContent:t});return new q(this.apiKey,i,s)}}const S={ANALYZE:e=>{var t,n;return`
      Analyze this candidate for a recruitment ERP system:
      Name: ${e.name}
      Role: ${e.role}
      Experience: ${e.experienceYears} years
      Skills: ${((n=(t=e.professionalProfile)==null?void 0:t.skills)==null?void 0:n.join(", "))||"None listed"}
      Location: ${e.location}
      Current Stage: ${e.stage}
      
      Provide a professional summary, assessment of their fit for the role, and recommended next steps.
      Format the output in clean Markdown.
    `},MATCH:(e,t)=>{var n,s,o;return`
      Match this candidate against the job requirements:
      
      CANDIDATE:
      Name: ${e.name}
      Role: ${e.role}
      Skills: ${((s=(n=e.professionalProfile)==null?void 0:n.skills)==null?void 0:s.join(", "))||"None listed"}
      Experience: ${e.experienceYears} years
      
      JOB:
      Title: ${t.title}
      Requirements: ${((o=t.requirements)==null?void 0:o.join(", "))||"None listed"}
      Description: ${t.description}
      
      Provide a match score between 0 and 100 and a brief reason (1-2 sentences).
      Output ONLY a JSON object like this: {"score": 85, "reason": "Excellent match..."}
    `},REPORT_INSIGHTS:(e,t)=>{var n,s,o,i;return`
      Generate executive recruitment insights for this candidate:
      Name: ${e.name}
      Current Stage: ${e.stage}
      Calculated Risk Score: ${t}
      Skills: ${((s=(n=e.professionalProfile)==null?void 0:n.skills)==null?void 0:s.join(", "))||"None listed"}
      Experience: ${e.experienceYears} years
      Target Job Roles: ${((i=(o=e.professionalProfile)==null?void 0:o.jobRoles)==null?void 0:i.map(a=>typeof a=="string"?a:a.title).join(", "))||"General Recruitment"}
      
      Provide the following in JSON format:
      1. strengths: Array of 3 key professional strengths.
      2. risks: Array of 2-3 potential recruitment or performance risks.
      3. placementProbability: A number (0-100) representing the likelihood of successful deployment.
      4. recommendedRoles: Array of 2 alternate or specific job roles they are qualified for.
      
      Return ONLY the JSON object.
    `},ANALYZE_SYSTEM:e=>`
      Analyze this recruitment agency system snapshot and provide an executive summary:
      KPIs: ${JSON.stringify(e.kpi)}
      Bottlenecks: ${JSON.stringify(e.bottlenecks)}
      Financials: ${JSON.stringify(e.financials)}
      
      Provide a concise 3-4 sentence professional assessment of the system's operational health, identifying the most critical focus area for the management team.
    `,SYSTEM_INSTRUCTIONS:`
You are the GlobalWorkforce Intelligence Advisor, a high-level recruitment data analyst and operational strategist. 
Your goal is to provide precise, data-driven, and actionable insights to agency managers.

- Maintain a professional, executive tone.
- When provided with SYSTEM SNAPSHOT data, use it to justify your claims.
- If a user asks about candidate health, refer to SLA compliance and data integrity.
- If a user asks about financials, focus on collected vs. projected revenue.
- Be proactive: if you see a bottleneck (e.g. medical stage delay), mention it.
- Format your responses using clean Markdown with bold headers and bullet points for readability.
- If you don't have enough data to answer a specific query, state what info is missing.
`},V="globalworkforce_gemini_api_key",W="globalworkforce_gemini_model",$e="gemini_cache_",Le=1e3*60*30,N=class N{static getApiKey(){return localStorage.getItem(V)||void 0||null}static getModelPref(){const t=localStorage.getItem(W);return t==="gemini-3-flash"||t==="gemini-2.0-flash"||t==="gemini-2.5-flash"?(this.saveModelPref("gemini-2.0-flash"),"gemini-2.0-flash"):t==="gemini-3.1-pro"||t==="gemini-1.5-pro"?(this.saveModelPref("gemini-1.5-pro-latest"),"gemini-1.5-pro-latest"):t==="gemini-1.5-flash"?(this.saveModelPref("gemini-1.5-flash-latest"),"gemini-1.5-flash-latest"):t||"gemini-2.0-flash"}static async getModel(){const t=this.getApiKey();if(!t)throw new Error("Gemini API Key not found in settings.");const n=new J(t),s=this.getModelPref();return n.getGenerativeModel({model:s})}static clearCache(){this.cache.clear()}static getCacheKey(t,n){return`${$e}${t}_${n}`}static getFromCache(t){const n=this.cache.get(t);return n?Date.now()-n.timestamp>Le?(this.cache.delete(t),null):n.data:null}static setCache(t,n){this.cache.set(t,{timestamp:Date.now(),data:n})}static async withRetry(t,n=2){try{return await t()}catch(s){if(n>0)return console.warn(`Gemini API call failed, retrying instantly... (${n} attempts left)`),await new Promise(o=>setTimeout(o,10)),this.withRetry(t,n-1);throw s}}static async getSystemAnalysis(t){try{return await this.withRetry(async()=>await(await(await this.getModel()).generateContent(S.ANALYZE_SYSTEM(t))).response.text())}catch(n){return console.error("Gemini System Analysis Error:",n),"Unable to generate AI System Analysis at this time. Please check your process configuration."}}static async getReportInsights(t,n){var i,a,r,c;const s=this.getCacheKey("report_insights",t.id),o=this.getFromCache(s);if(o)return console.log("Gemini: Serving report insights from cache"),o;try{const u=await this.withRetry(async()=>{const l=(await(await(await this.getModel()).generateContent(S.REPORT_INSIGHTS(t,n))).response.text()).match(/\{[\s\S]*\}/);if(!l)throw new Error("No JSON found in response");return JSON.parse(l[0])});return this.setCache(s,u),u}catch(u){return console.error("Gemini Report Insights Error:",u),{strengths:((a=(i=t.professionalProfile)==null?void 0:i.skills)==null?void 0:a.slice(0,3))||["Candidate","Profile","Ready"],risks:n==="HIGH"?["High Risk Assessment","Documentation Gaps"]:["None obvious"],placementProbability:n==="HIGH"?50:80,recommendedRoles:((c=(r=t.professionalProfile)==null?void 0:r.jobRoles)==null?void 0:c.map(h=>typeof h=="string"?h:h.title).slice(0,2))||["General Helper"]}}}static async analyzeCandidate(t){const n=this.getCacheKey("analysis",t.id),s=this.getFromCache(n);if(s)return console.log("Gemini: Serving analysis from cache"),s;try{const o=await this.withRetry(async()=>await(await(await this.getModel()).generateContent(S.ANALYZE(t))).response.text());return this.setCache(n,o),o}catch(o){const i=o instanceof Error?o.message:String(o);return console.error("Gemini Analysis Error:",o),`AI Analysis Failed: ${i}. Please check your API key in Settings.`}}static async chat(t,n){try{return await this.withRetry(async()=>{const s=await this.getModel();let o="";if(n)o=`SYSTEM SNAPSHOT (LIVE DATA FEED):
- Metrics: ${n.kpi.totalCandidates} Total, ${n.kpi.activeProcessing} Active.
- Financials: $${n.financials.totalCollected.toLocaleString()} Collected.
- Potential: $${n.financials.pipelineValue.toLocaleString()}.
- Critical Bottlenecks: ${n.bottlenecks.filter(c=>c.status==="Critical").map(c=>`${c.stage} (${c.count} delayed)`).join(", ")||"None"}.`;else if(t.toLowerCase().includes("data")||t.toLowerCase().includes("stat")){const{ReportingService:c}=await ne(async()=>{const{ReportingService:h}=await import("./reportingService-DKNwFCwn.js");return{ReportingService:h}},__vite__mapDeps([0,1,2])),u=await c.getSystemSnapshot();o=`SYSTEM SNAPSHOT (AUTO):
- Total: ${u.kpi.totalCandidates}
- Collected: $${u.financials.totalCollected.toLocaleString()}
- Bottlenecks: ${u.bottlenecks.filter(h=>h.status==="Critical").length} Critical stages.`}const i=`
${S.SYSTEM_INSTRUCTIONS}

USER CONTEXT/SYSTEM DATA:
${o||"No specific system context provided for this query."}

USER QUERY:
${t}

RESPONSE:`;return(await(await s.generateContent(i)).response).text()})}catch(s){return console.error("Gemini Chat Error:",s),`AI Chat Failed: ${s instanceof Error?s.message:String(s)}. Please ensure you've configured a valid API Key in the Settings tab.`}}static async getMatchScore(t,n){const s=this.getCacheKey("match",`${t.id}_${n.id}`),o=this.getFromCache(s);if(o)return console.log("Gemini: Serving match score from cache"),o;try{const i=await this.withRetry(async()=>{const u=(await(await(await this.getModel()).generateContent(S.MATCH(t,n))).response.text()).match(/\{[\s\S]*\}/);if(!u)throw new Error("No JSON found in response");return JSON.parse(u[0])});return this.setCache(s,i),i}catch(i){return console.error("Gemini Match Error:",i),{score:0,reason:"Match analysis failed."}}}static saveApiKey(t){localStorage.setItem(V,t)}static saveModelPref(t){localStorage.setItem(W,t)}static hasApiKey(){return!!this.getApiKey()}static async testConnection(t,n){var s;try{return(await(await new J(t).getGenerativeModel({model:n}).generateContent("Respond with the exact word: OK")).response.text()).toLowerCase().includes("ok")?{success:!0,message:`Successfully connected to ${n}`}:{success:!1,message:"Connected, but received unexpected response format."}}catch(o){return{success:!1,message:(s=o.message)!=null&&s.includes("API key not valid")?"Invalid API Key provided.":`Connection Error: ${o.message||"Unknown error"}`}}}};N.cache=new Map;let X=N;export{X as G};
