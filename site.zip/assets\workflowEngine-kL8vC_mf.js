import{W as e}from"./index-BBTYFYMN.js";e.getNextStage.bind(e);
